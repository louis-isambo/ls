function uuid() {
    var letters = "abcdefghigklmnopqrstuvwxyz";
    var subLetters = letters.slice(10, letters.length);
    var sequence = [letters, letters.toUpperCase(),
        subLetters, subLetters.toUpperCase()];
    var DateTime = new Date();
    var msec = DateTime.getMilliseconds();
    var sec = DateTime.getSeconds();
    var ms = DateTime.getMinutes();
    var hr = DateTime.getHours();
    var day = DateTime.getDay();
    var mth = DateTime.getMonth();
    var year = DateTime.getFullYear();
    var resArr = [msec, sec, ms, hr, day, mth, year];
    var [result, str] = ["", ""];
    resArr.forEach(item => {
        result += `${item}${Math.floor(Math.random() * item)}`;
    });
    for (var x of result) {
        var seq = Math.floor(Math.random() * sequence.length);
        str += sequence[seq][x];

    }
    return str;
}

var ENCO = [8364, 163, 171, 187, 8240, 247, 165,
    39, 34, 96, 97, 98, 99, 100, 101, 102, 103,
    104, 105, 106, 107, 108, 109, 110, 111, 112,
    113, 114, 115, 116, 117, 118, 119, 121, 122,
    65, 66, 67, 68, 69, 70, 71, 72, 73, 74, 75,
    76, 77, 78, 79, 80, 81, 82, 83, 84, 85, 86,
    87, 88, 89, 90, 48, 49, 50, 51, 52, 53, 54,
    55, 56, 57, 45, 95, 46, 47, 59, 40, 41, 38,
    64, 63, 44, 91, 93, 123, 125, 35, 37, 94, 42,
    43, 61, 124, 36, 126, 60, 62, 8800, 215, 167];


var DEC = {};
var OBJ_ENCO = {};
var limit = 100;
var SEP = [120, 33];
for (var x = 0; x < limit; x++) {
    if (x <= 9) {
        OBJ_ENCO[`0${x}`] = `${ENCO[x]}`;
    }
    else {
        OBJ_ENCO[`${x}`] = `${ENCO[x]}`;

    }
    DEC[`${ENCO[x]}`] = `${x}`;
}

function encode(text) {
    var codeChrs = text.split("").map(item => item.charCodeAt());
    var listChars = [];

    codeChrs.forEach((item, index) => {
        item = String(item);
        if (item.length % 2 !== 0) {
            var last = item[item.length - 1];
            item = item.slice(0, item.length - 1) + `0${last}`;

        }
        listChars.push(item);
    });

    var result = new String("");
    listChars.forEach(item => {
        readSlice(item, 2, function (data, end) {
            result += String.fromCharCode(OBJ_ENCO[data]);
            var sep = Math.floor(Math.random() * SEP.length);
            if (end) result += String.fromCharCode(SEP[sep]);
        });
    });
    return result
}

function decode(text) {
    var chars = text.split(
        new RegExp(`(${String.fromCharCode(SEP[0])}|${String.fromCharCode(SEP[1])})`, "g"))
        .map(item => {
            if (item.length === 1 && (SEP.indexOf(item.charCodeAt()) === -1)) {
                return Number.parseInt(DEC[item.charCodeAt()])
            }
            if (item.length >= 2) {
                var resChr = "";
                for (var chr of item) {
                    resChr += `${DEC[chr.charCodeAt()]}`;
                }
                return Number.parseInt(resChr)
            }
        });
    chars = chars.filter(item => item != undefined)
        .map(item => String.fromCharCode(item)).join("");
    return chars
}

function readSlice(text, num, callback) {
    var [counter, temp] = [0, ""];
    for (var x = 0; x < text.length; x++) {
        counter++;
        temp += text[x];
        if (counter === num) {
            if (callback) callback(temp, end = x === text.length - 1);
            temp = "";
            counter = 0;
        }
    }
}

var index = /*#__PURE__*/Object.freeze({
    __proto__: null,
    decode: decode,
    encode: encode
});

/**
 * **EventEmitter** in Leistrap
 * 
 * The `EventEmitter` is a core utility in Leistrap designed to create unique, bidirectional communication channels.
 * It facilitates asynchronous and fluid information sharing between various UI components and elements within the application. 
 * Thanks to its core methods, **`handle`** and **`invoke`**, the EventEmitter enables seamless event-driven communication 
 * between objects, promoting better decoupling and reusability.
 * 
 * - **Key Features**:
 *   - **`handle`**: Define a channel and attach a listener to it.
 *   - **`invoke`**: Trigger a channel, executing its attached listener if it exists.
 *   - **`removeEvent`**: Remove a channel if it's removable.
 *   - **`hasEvent`**: Check if a channel exists.
 *   - **`eventsList`**: Get a list of all registered channels.
 *   - **`clear`**: Cleanup all registered channels and events.
 */
const lsEmitter = function (obj) {

    let channels = {};
    let inWaitChannel = {};
    let data = null;
    let isDestroyed = false;

    const event_ = { send: (d) => { data = d; } };

    function validateChannelName(channel) {
        if (!channel || typeof channel !== "string" || channel.trim() === "") {
            throw new EventEmitterError(
                "Invalid channel name: The channel name must be a non-empty string.",
                "INVALID_CHANNEL_NAME"
            );
        }
     }
    

     function checkState(){
        if(isDestroyed){
            throw new EventEmitterError(
                "Operation failed: The EventEmitter instance has been destroyed.\n " +
                "No further actions can be performed on this instance.\n " +
                "Ensure you are not referencing a cleared or invalid EventEmitter object.\n",
                "EVENT_DESTROYED"
            );
        }
     }

    class EventEmitterError extends Error {
        constructor(message, code) {
            super(message);
            this.name = "EventEmitterError";
            this.code = code; 
        }
    }


        
    /**
     * **`invoke`**: Trigger a channel and execute its listener.
     * 
     * This method is used to invoke a channel. If the channel does not exist yet, it is added to a queue 
     * and invoked as soon as it is defined via **`handle`**.
     * 
     * @param {string} channel - The name of the channel to invoke.
     * @param {function|null} [listener=null] - A callback function to execute immediately after the channel's listener 
     *                                          is invoked. This callback receives data sent from the channel's listener 
     *                                          through **`event.send(data)`**. Can be `null` if no additional processing is needed.
     * @param {...any} args - Additional arguments to pass to the channel's listener. These can include strings, arrays, 
     *                        objects, or asynchronous callbacks.
     * 
     * **Note**: It is recommended to use asynchronous callbacks if you need to handle complex operations.
     * 
     * **Example Usage**:
     * ```javascript
     * eventEmitter.invoke("myChannel", (data) => {
     *     console.log("Response from listener:", data);
     * }, "arg1", { key: "value" });
     * ```
     */
    async function invoke(channel, listener, ...args) {

        validateChannelName(channel);
    
        async function exe() {
            if ( !isDestroyed  && channels[channel]) {
                await channels[channel].listener(event_, ...args);
            }
            if ( !isDestroyed && listener) listener(data);
            data = null;
        }
    
        if (!isDestroyed && obj.has(channel, channels)) {
            obj.after(1, exe);
        } else {
            if(!inWaitChannel[channel]) inWaitChannel[channel] = [];
            inWaitChannel[channel].push(() => obj.after(1, exe));
        }
    }



     /**
     * **`handle`**: Define a new channel and attach a listener to it.
     * 
     * This method is used to create a channel and listen for invocations on it via **`invoke`**.
     * 
     * @param {string} channel - The name of the channel to create.
     * @param {function} listener - The handler function to be called when the channel is invoked. 
     *                              The first parameter of this function must always be **`event`**, 
     *                              which is used to send immediate data to the listener via **`event.send(data)`**.
     *                              Additional parameters can be passed through **`...args`**.
     * @param {boolean} [removable=true] - Indicates whether the channel can be removed later using **`removeEvent`**. 
     *                                     Default is `true`. If set to `false`, the channel cannot be removed.
     * @param {boolean} [writable=true] - Defines whether the channel can be overwritten. Default is `true`. 
     *                                    If set to `false`, the channel becomes immutable and cannot be modified.
     * 
     * **Example Usage**:
     * ```javascript
     * eventEmitter.handle("myChannel", (event, data) => {
     *     console.log("Data received:", data);
     *     event.send({ success: true });
     * }, true, true);
     * ```
     */
    async function handle(channel, listener, removable = true, writable = true) {
        checkState();
        validateChannelName(channel);
    
        if (obj.has(channel, channels) && !channels[channel].writable) {
            throw new EventEmitterError(
                `Cannot redefine the channel "${channel}" because it is marked as non-writable.`,
                "NON_WRITABLE_CHANNEL"
            );
        }
    
        if (obj.has(channel, inWaitChannel)) {
            inWaitChannel[channel].forEach(function(item){
                item();
            });
            delete inWaitChannel[channel];
        }

        channels[channel] = { listener, removable, writable };
    }
    

    
    /**
     * **`removeEvent`**: Remove a registered channel.
     * 
     * This method removes a channel from the EventEmitter. If the channel is not marked as **`removable`**, 
     * it will throw an error.
     * 
     * @param {string} channel - The name of the channel to remove.
     * @throws {Error} If the channel is not removable.
     * 
     * **Example Usage**:
     * ```javascript
     * eventEmitter.removeEvent("myChannel");
     * ```
     */
    function removeChannel(channel) {
        checkState();
        validateChannelName(channel);
    
        if (!obj.has(channel, channels)) {
            throw new EventEmitterError(
                `Cannot remove the channel "${channel}" because it does not exist.`,
                "CHANNEL_NOT_FOUND"
            );
        }
    
        if (!channels[channel].removable) {
            throw new EventEmitterError(
                `Cannot remove the channel "${channel}" because it is marked as non-removable.`,
                "NON_REMOVABLE_CHANNEL"
            );
        }
    
        delete channels[channel];
    

        if (obj.has(channel, inWaitChannel)) {
            delete inWaitChannel[channel];
        }
    
        if (data && data.channel === channel) {
            data = null;
        }
        
    }
    
    /**
     * **`clear`**: Cleanup all registered channels and events.
     * 
     * This method removes all channels, listeners, and pending events from the EventEmitter. 
     * It ensures that no memory leaks occur and that the EventEmitter can be safely discarded.
     * 
     * **Example Usage**:
     * ```javascript
     * eventEmitter.clear();
     * ```
     */

    function clear() {
        checkState();
        Object.keys(channels).forEach(channel => {
            delete channels[channel];
        });
    
  
        Object.keys(inWaitChannel).forEach(channel => {
            delete inWaitChannel[channel];
        });
        
        Object.keys(EVENTS).forEach(meth => {
            EVENTS[meth] = checkState;
        });

        data = null;
        EVENTS = null;
        channels = null;
        inWaitChannel = null;
        isDestroyed = true;
        return true
    }
    
    
     /**
     * **`eventsList`**: Get a list of all registered channels.
     * 
     * This method returns an array containing the names of all currently registered channels.
     * 
     * @returns {string[]} - Array of channel names.
     * 
     * **Example Usage**:
     * ```javascript
     * console.log("Registered channels:", eventEmitter.eventsList());
     * ```
     */
    let  eventsList  = ()=> Object.keys(channels);


        /**
     * **`hasEvent`**: Check if a channel exists.
     * 
     * This method verifies whether a channel is registered in the EventEmitter.
     * 
     * @param {string} channel - The name of the channel to check.
     * @returns {boolean} - Returns `true` if the channel exists, otherwise `false`.
     * 
     * **Example Usage**:
     * ```javascript
     * if (eventEmitter.hasEvent("myChannel")) {
     *     console.log("Channel exists!");
     * }
     * ```
     */
    let  hasEvent = (channel) => obj.has(channel, channels);


    let EVENTS =  {
        invoke,
        handle,
        removeEvent: removeChannel,
        removeChannel,
        hasEvent,
        eventsList,
        clear
    };

    return EVENTS
};

function isElementOf(item, list) {
    /* returns true if item given in the array given*/
    this.dict = {};
    list.forEach(element => {
        this.dict[element] = element;
    });
    if (item in this.dict) { return true }
    else { return false }
}

function Union(item = []) {
    this.result = [];
    this.dict = {};
    for (var data = 0; data < item.length; data++) {
        for (var i = 0; i < item[data].length; i++) {
            if (item[data][i] in this.dict == false) {
                this.dict[item[data][i]] = item[data][i];
                this.result.push(item[data][i]);
            }
        }
    }
    return this.result
}

function inter(item_1, item_2) {
    this.list = Union([item_1, item_2]);
    this.result = [];
    this.list.forEach(elem => {
        if (isElementOf(elem, item_1) && isElementOf(elem, item_2)) {
            this.result.push(elem);
        }
    });
    return this.result;
}


function countArray(arr, offset) {
    var counter = offset;
    return function () {
        if (counter === arr.length - 1) counter = 0;
        var v = arr[counter];
        counter++;
        return v;
    }
}

// maths operators

function generateId(min = 0, max = 1) {
    const sy = "dh5263ayLogl";
    const num = "0123456789";
    const letters = "abcdefghijklmnopqrstuvwxyz";
    const lettUpc = letters.toLocaleUpperCase();
    const allItem = [sy, num, letters, lettUpc];
    let [res, i, y] = ["", 0, 0];
    const len = randint(min, max);

    while (y < len) {
        for (i = 0; i < allItem.length; i++) {
            let _c = allItem[Math.floor(Math.random() * allItem.length)];
            res += _c[Math.floor(Math.random() * _c.length)];
        }
        y++;
    }
    return res
}

function choice(obj) {

    if (typeof obj === "object") {
        const _bj = Object.keys(obj);
        return (obj[_bj[Math.floor(Math.random() * _bj.length)]]);
    }
    else if (
        typeof obj === "function"
        || typeof obj === "boolean"
        || typeof obj === "undefined"
        || typeof obj === "symbol"
    ) {
        throw new Error(`can not execute a ${typeof obj}`)
    }
    else if (typeof obj === "number") {
        const _n = [];
        for (let i = 0; i < obj; i++) { _n.push(i); }
        return _n[Math.floor(Math.random() * _n.length)]
    }
    else if (typeof obj === "string") {
        return obj[Math.floor(Math.random() * obj.length)]
    }
}

function randint(min, max) {

    if (typeof min === "number" && typeof max === "number") {
        const _p = [];
        for (let _x = min; _x < max; _x++) {
            _p.push(_x);
        }
        return choice(_p)

    }
    else {
        throw new Error(`can not execute ${typeof min !== "number" ? typeof min : typeof max}`)
    }
}

function maxArray(array = []) {
    if (typeof array === "object") {
        if (typeof array.push !== "function")
            throw new Error(`can not execute a (an) ${typeof array}`)
        else {
            let _x = array[0];
            array.forEach(item => {
                _x = item > _x ? item : _x;
            });
            return _x
        }
    }
}
function minArray(array = []) {
    if (typeof array === "object") {
        if (typeof array.push !== "function")
            throw new Error(`can not execute a (an) ${typeof array}`)
        else {
            let _x = array[0];
            array.forEach(item => {
                _x = item < _x ? item : _x;
            });
            return _x
        }
    }
}
function reverse(obj) {
    if (typeof obj === "object") {

        let _type = typeof obj.push === "function" ? "a" : "o";
        if (_type === "a") {
            const _p = [];
            for (let x = 0; x < obj.length; x++) {
                _p.push(obj[(obj.length - 1) - x]);
            }
            return _p
        }
        else if (_type === "o") {
            const _o = {};
            const _xp = Object.keys(obj);
            _xp.forEach((item, i) => {
                _o[_xp[(_xp.length - 1) - i]] = obj[_xp[(_xp.length - 1) - i]];
            });
            return _o
        }

    }
    else if (
        typeof obj === "function"
        || typeof obj === "boolean"
        || typeof obj === "undefined"
        || typeof obj === "symbol"
        || typeof obj === "number"
    ) {
        throw new Error(`can not execute a ${typeof obj}`)
    }
    else if (typeof obj === "string") {
        let [_r, i] = ["", 0];
        for (let x of obj) {
            i++;
            _r += obj[obj.length - i];
        }
        return _r
    }

}

function splitData(data, step, proto = "length") {
    let temp = [];

    while (data[proto] > step) {
        temp.push(data.slice(data[proto] - step, data[proto]));
        data = data.slice(0, data[proto] - step);
    }

    if (data[proto] <= step) temp.push(data.slice());
    return temp
}


function inverseObject(_obj) {
    const result = {};
    loopObject(_obj, function (value, key) {
        result[value] = key;
    });
    return result
}

function rangeList(num, offset = 0, step = 1) {
    const result = [];
    for (let x = offset; x < num; x++) {
        if (x % step == 0) result.push(x);
    }
    return result
}

/**
 *  tests if an variable is not defined,
 * it returns `true` if the variable is not defined
 * otherwise it returns `false`
 * @param {*} obj 
 * @returns boolean
 */
function isUndefined(obj) { return !obj; }


function isArray(obj) {
    return obj.constructor.toString().indexOf("Array") > -1
}
function isObject(obj) {
    return obj.constructor.toString().indexOf("Object") > -1;
}

function isString(obj) {
    if (typeof obj === "string") {
        return true
    }
    return obj instanceof String
}

function isNumber(obj) {
    return !isNaN(obj)
}

function isFunction(obj) {
    return typeof obj === "function";
}

function setEmptyArray(arr) {
    return arr.splice(0, arr.length);
}

function isNone(obj) {
    return isString(obj) && obj == ""
}

function isEmpty(obj) {
    return obj.length === 0 || Object.keys(obj).length === 0
}

function has(prop, obj) {
    return obj.indexOf ? obj.indexOf(prop) > -1 : obj.hasOwnProperty(prop)
}
function isTypeOf(prop, obj) {
    return prop instanceof obj
}

function copyObject(obj, target, overwrite = false, ...exp) {
    if (!target) { target = {}; }    if (!obj) { obj = {}; }    Object.keys(obj).forEach(item => {
        if (!(has(item, target) && !overwrite)) {
            if (!has(item, exp)) {
                target[item] = obj[item];
                if (isArray(target)) { target[item] = obj[item]; }
            }
        }
    });
    return target
}

function copyArray(arr, target, overwrite = false) {
    if (!target) { target = []; }    if (!(!arr)) {
        arr.forEach((item, index) => {
            if (!(has(item, target) && !overwrite)) { target.push(item); }
        });
    } return target
}


function getUrl(o) {
    return o.match(/http+(s|\b):\/\/[^ ]*(?=\b)+(\s|\b|\/)*/gi)
}

function hasUrl(o) {
    return !(!getUrl(o))
}

function arrayRemove(index, arr) {
    return arr.splice(index, 1)
}

function arrayReplace(index, value, arr) {
    return arr.splice(index, 1, value)
}

function arrayInsert(index, arr, args) {
    arr.splice(index, 0, args);
}

function tryCode(callback, error) {
    try { callback(); } catch (e) { if (error) { error(e); } }
}

function after(s, func, ...args) {
    return setTimeout(func, s, args)
}


function loopObject(obj, callback = (value, key, index, finished) => value) {
    const result = [];
    if (obj) {
        let c = 0; let f = false;
        for (var x in obj) {
            c++;
            c === Object.keys(obj).length ? f = true :
                f = false;
            callback(obj[x], x, c - 1, f);
            result.push(obj[x]);
        }
    }
    return result
}

function bindFunc(fc, bc) {
    return function (...e) { return fc.call(bc, ...e) }
}

function arrAddWhen(arr, item, num1, num2, callback) {
    if (num1 <= num2) {
        if (arr) { arr.push(item); } if (callback) {
            callback(item);
        }
    }
}


function arrBegin(condi, callback) {
    if (condi) { callback(); }
}

function initObj(obj, value) {
    obj = obj ? obj : value;
    return obj
}

function objKeysToLowerCase(o) {
    const target = {};
    loopObject(o, (item, x) => target[x.toLowerCase()] = item);
    return target
}


function filter(o, callback) {
    const r = {};
    loopObject(o, (...args) => {
        if (callback(...args)) { r[args[1]] = args[0]; }
    }); return r
}


function defineObj(obj, proName, value, writable = false) {
    return Object.defineProperty(obj, proName, { value, writable })
}


function capitalize(value){
    if(typeof value === "string"){
        let cpv = value.slice(1);
        let cp = value[0].toUpperCase();
        return cp +cpv
    }

    return value
}


function toCamelKey (key){
    return key.replace(/-([a-z])/g, (_, char) => char.toUpperCase());
}

function _EventEmitter(){
    return lsEmitter({ has, after, copyObject })
}
const event = _EventEmitter();

let leisCode = index
module.exports = { Union, _EventEmitter, after, arrAddWhen, arrBegin, arrayInsert, arrayRemove, arrayReplace, bindFunc, capitalize, choice, copyArray, copyObject, countArray, defineObj, event, filter, generateId, has, hasUrl, initObj, inter, inverseObject, isArray, isElementOf, isEmpty, isFunction, isNone, isNumber, isObject, isString, isTypeOf, isUndefined, leisCode, loopObject, maxArray, minArray, objKeysToLowerCase, randint, rangeList, reverse, setEmptyArray, splitData, toCamelKey, tryCode, uuid };
