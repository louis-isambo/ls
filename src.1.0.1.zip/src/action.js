
const fs = require('fs');
const unzipper = require('unzipper');
const axios = require('axios');
const archiver = require('archiver');
const tar = require('tar');
const path = require('path');

function unzipFile(zipPath, outputPath, onSuccess, onError) {
    fs.createReadStream(zipPath)
        .pipe(unzipper.Extract({ path: outputPath }))
        .on('close', onSuccess)
        .on('error', onError);
}


function deleteFolder(folderPath, onSuccess, onError) {
    fs.rm(folderPath, { recursive: true, force: true }, (err) => {
        if (err) {
            onError(err)
            return 
        }
        onSuccess()
    });
}


async function downloadFile(url, outputPath, onSuccess, onError) {
    try {
        const response = await axios({
            method: 'GET',
            url,
            responseType: 'stream'
        });

        const file = fs.createWriteStream(outputPath);
        response.data.pipe(file);

        file.on('finish', () => {
            onSuccess()
        });

    } catch (error) {
       onError(error)
    }
}




function zipFolder(folderPath, outputPath, onSuccess, onError) {
    const output = fs.createWriteStream(outputPath);
    const archive = archiver('zip', { zlib: { level: 9 } }); 

    output.on('close', () => {
        onSuccess()
    });

    archive.on('error', (err) => {
       onError(err)
    });

    archive.pipe(output);
    archive.directory(folderPath, false); 
    archive.finalize(); 
}




function tarFolder(folderPath, outputPath, onSuccess, onError) {
    tar.c(
        { gzip: true, file: outputPath },
        [folderPath]
    ).then(() => onSuccess())
     .catch(err => onError(err));
}




function deleteFile(filePath, onSuccess, onError) {
    fs.access(filePath, fs.constants.F_OK, (err) => {
        if (err) {
            return onError(err)
        }

        fs.unlink(filePath, (err) => {
            if (err) return onError(err)
            onSuccess()
        });
    });
}



function moveFile(source, destination) {
    fs.rename(source, destination, (err) => {
        if (err) {
            console.error(`Erreur lors du déplacement : ${err.message}`);
        } else {
            console.log(`✅ Fichier déplacé vers : ${destination}`);
        }
    });
}


const fileNames_ = [
    "main.js",
    "config.json",
    "action.js",
    "preload.js"
]


function updateSrc(fileNames, destination){
    fileNames.forEach(file => {
        deleteFile(path.join(__dirname, file), function(){
            moveFile(destination+file, file)
        }, function(){
            console.log("fail to remane file ", file);
            
        })
    });
}



function startUpdating(callback){
    deleteFolder(path.join(__dirname, "src"), function(){
        unzipFile(path.join(__dirname, "src.zip"),  __dirname,
        function(){
            updateSrc(fileNames_, path.join(__dirname, "src"))
            console.log("update is done !");
            console.log("app is installed");
            setTimeout(callback, 3000)
            deleteFile(path.join(__dirname, "src.zip"), function(){}, function(){})
            
        },
        function(){
            console.log("the app instalation is failed !");
            
        }
        )
    }, 
    function(){
        console.log("start installation ...");
        }
    )
}

function updateApp(version, callback){
    console.log("start downloading ...", version);
    
    downloadFile(`https://louis-isambo.github.io/ls/src.${version}.zip`,
         path.join(__dirname, "src.zip"), function(){
        callback(startUpdating)
    },

    function(err){
        console.log('fail to download', err);
    }

    )

}


module.exports = {
    unzipFile,
    deleteFolder,
    downloadFile,
    zipFolder,
    tarFolder,
    deleteFile,
    updateApp

}