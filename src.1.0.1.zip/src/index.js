
const { BrowserWindow, app, ipcMain } = require("electron");
const path = require("path");
const { fork } = require('child_process');
const fs = require("fs");
const { log } = require("console");


function runApp (){

    let server = createServerProcess(path.join(__dirname, "server/server.js"))
    let isServer ;

    function createServerProcess(pcPath){

        const serverProcess = fork(pcPath); 
        serverProcess.on('message', (message) => {
            console.log(`Message du serveur : ${message}`);
            message = JSON.parse(message)
            if(isServer && message.url){
                isServer(message.url)
            }
        });

        serverProcess.on('exit', (code) => {
            console.log(`Le serveur s'est arrêté avec le code ${code}`);
        });

        // Arrêter le serveur proprement
        process.on('SIGINT', () => {
            serverProcess.kill(); // Tue le processus enfant
            console.log('Serveur arrêté.');
            process.exit();
        });
        return serverProcess

    }

        
    function createWin() {
        const win = new BrowserWindow({
            width: 700,
            height: 650,
            webPreferences: {
                preload: path.join(__dirname, "preload.js"),
                nodeIntegration : true
            },
            // frame: false,
            // center: true,
            // resizable: false,
            // roundedCorners: true,
            // transparent: true
        })

        // win.loadFile("./index.html")
        return win
    }


    app.whenReady().then(() => {
        const win = createWin()

        isServer = function(url){
            win.loadURL(url)
        }
        app.on("activate", function () {
            if (BrowserWindow.getAllWindows().length === 0) MainWin()
        })

        app.on("window-all-closed", function () {
            if (process.platform !== "darwin") app.quit()
        })
    })
}

module.exports = {runApp}