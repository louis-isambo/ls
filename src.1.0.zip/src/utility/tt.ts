
export declare namespace _EventEmitter {

    type eventChannel = "main" | "readContent"
    type leisEvent = {
        send: (data: any) => void
    }
    function handle(channel: string, listener: (event: leisEvent, args: any) => void): Promise<void>
    function invoke(channel: eventChannel, listener: (data: any) => void | null): Promise<void>
    function removeEvent(channel: string): void
    function eventsList(): Array<string>
    function hasEvent(channel: string): boolean
}